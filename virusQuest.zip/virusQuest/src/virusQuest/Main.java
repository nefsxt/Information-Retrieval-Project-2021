package virusQuest;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;

public class Main {

	
	
	public static void main(String args[]) throws IOException, ParseException 
	{
		
		int start=0;
		int end=10;
		
		indexMaker idx = new indexMaker(2,"C:\\Users\\Nefeli\\Desktop\\index");
		
		
		//temporary result collections for 
		ArrayList<String> authors = new ArrayList<String>();
		ArrayList<String> topics = new ArrayList<String>();
		ArrayList<String> dates = new ArrayList<String>();
		ArrayList<String> titles = new ArrayList<String>();
		ArrayList<String> content = new ArrayList<String>();

		idx.indexer();
		idx.accessIdxDoc("body", 1);
		System.out.println("out of access");
		Searcher s = new Searcher("C:\\Users\\Nefeli\\Desktop\\index","C:\\Users\\Nefeli\\Desktop\\spellIndex");
		TopDocs results = s.search("buttercup OR tralalalalalalal");
		//s.nextPrev(results, start, end);
		authors = s.nextPrevField(results,start,end,"author");
		topics = s.nextPrevField(results,start,end,"topic");
		dates = s.nextPrevField(results,start,end,"date");
		titles =s.nextPrevField(results,start,end,"title");
		content = s.nextPrevField(results,start,end,"body");
		
		
		for(int i=0;i<authors.size();i++) 
		{
			System.out.println(authors.get(i));
		}
		
		
		
		
		
		s.closeSearch();
		
	}
	
}
