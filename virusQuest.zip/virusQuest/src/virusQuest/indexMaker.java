package virusQuest;


import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FieldType;

import org.apache.lucene.index.IndexOptions;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;



import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;





public class indexMaker {

	private int n;
    private File dirFile;
    private Directory dir;
    private IndexWriterConfig config;
	private IndexWriter idxWriter;
	//private FieldType metadataFieldSet;
	private FieldType contentFieldSet;
	
	
		public indexMaker(int n, String dirPath) throws IOException 
		{
			this.n = n;		// number of corpus docs to be indexed
		    this.dirFile = new File(dirPath);
		    this.dir = FSDirectory.open(dirFile.toPath());
		    StandardAnalyzer analyzer = new StandardAnalyzer();
		    this.config = new IndexWriterConfig(analyzer);
			this.config.setOpenMode(IndexWriterConfig.OpenMode.CREATE);		//overrides original index everytime app opens
			this.idxWriter = new IndexWriter( dir, config );
			
			

			// field settings for metadata fields
			/*
			this.metadataFieldSet = new FieldType();
			this.metadataFieldSet.setOmitNorms(true); 					// set to true to omit normalization values for the field
			this.metadataFieldSet.setIndexOptions(IndexOptions.DOCS); 	// sets the indexing options for the field, we only care about which doc this data belongs to here
			this.metadataFieldSet.setTokenized(false); 					// do NOT tokenize
			this.metadataFieldSet.setStored(true);						// STORE
			this.metadataFieldSet.freeze();								// prevent future changes
			*/
			
			//field settings for normal text/content fields
			this.contentFieldSet = new FieldType();
			this.contentFieldSet.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS); //	we want to be able to get docs,frequency and positions for terms
			this.contentFieldSet.setStoreTermVectors(true); 								 // STORE term vectors 
			this.contentFieldSet.setStoreTermVectorPositions(true); 						 // STORE vector positions 
			this.contentFieldSet.setTokenized(true); 										 //	TOKENIZE
			this.contentFieldSet.setStored(true);	 										 // STORE
			this.contentFieldSet.freeze(); 													 // prevent future changes
			
		}
		
		
		public void indexer() throws IOException 
		{
			
			 for(int i=1; i<=this.n;i++)
			    {
			      //String filePath="C:\\Eclipse\\workspace\\VirusQuest\\Data\\covid19_data"+i+".txt"; //filepath
			      String filePath="C:\\Users\\Nefeli\\eclipse-workspace\\virusQuest\\resources\\corpus\\covid19_data"+i+".txt"; //filepath

			      File txtfile = new File(filePath); // open file located at given path

			      Scanner fileScan = new Scanner(txtfile); //use the scanner to read the file
			      String author=""; //initialize fields
			      String topic="";
			      String date="";
			      String title="";
			      String body="";
			      String tempLine;

			      Document doc = new Document();
			      
			      int lineCount = 0;
			      while(fileScan.hasNextLine())
			      {
			        if(lineCount==0)
			        {     //author field, read first line and create it
			              author = fileScan.nextLine();
			              //System.out.println(author);
			              lineCount++;
			        }
			        else if(lineCount==1)
			        {     //topic field, read second line and create it
			              topic= fileScan.nextLine();
			              //System.out.println(topic);
			              lineCount++;
			        }
			        else if(lineCount==2)
			        {     //date field, read third line and create it
			              date = fileScan.nextLine();
			              //System.out.println(date);
			              lineCount++;
			        }
			        else if(lineCount==3)
			        {     //title field, read fourth line and create it
			              title = fileScan.nextLine();
			              //System.out.println(title);
			              lineCount++;
			        }
			        else
			        {     //body field, read the rest to create
			              tempLine= body;
			              body = tempLine+" "+fileScan.nextLine();
			              //System.out.println(body);
			              lineCount++;
			        }
			       
			      }

			    //setting the fields...
			      doc.add(new Field("author",author,this.contentFieldSet));
			      //System.out.println(author);
			      doc.add(new Field("topic",topic,this.contentFieldSet));
			      //System.out.println(topic);
			      doc.add(new Field("date",date,this.contentFieldSet));
			     // System.out.println(date);
			      doc.add(new Field("title",title,this.contentFieldSet));
			      //System.out.println(title);
			      doc.add(new Field("body",body,this.contentFieldSet));
			      //System.out.println("BODY-----------------------");
			      //System.out.println(body);
			      
			      this.idxWriter.addDocument(doc);
			    
			      
			    }

			   // closing the IndexWriter and Directory
			   System.out.println("CLOSING...");
			   this.idxWriter.close();
			   this.dir.close();
			   
			   
		}
		
		
		
	
	
}
