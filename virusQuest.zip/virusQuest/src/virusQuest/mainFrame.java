package virusQuest;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;

import java.util.ArrayList;
import java.util.Scanner;


import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JList;

import javax.swing.BoxLayout;


import org.apache.commons.io.input.ReversedLinesFileReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.TopDocs;


import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.nio.charset.Charset;
import java.awt.event.ActionEvent;


public class mainFrame extends JFrame {

	private JPanel contentPane;
	private JTextField inputLine;
	private int start=0;
	private int end=10;
	//temporary result collections for 
	private ArrayList<String> authors = new ArrayList<String>();
	private ArrayList<String> topics = new ArrayList<String>();
	private ArrayList<String> dates = new ArrayList<String>();
	private ArrayList<String> titles = new ArrayList<String>();
	private ArrayList<String> content = new ArrayList<String>();
	private ArrayList<String> spellSugg = new ArrayList<String>();
	private TopDocs results ;
	private int historyCounter=0;
	
	/**
	 * Launch the application.
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		
		//open index at given path
		indexMaker idx = new indexMaker(700,"C:\\Users\\Nefeli\\eclipse-workspace\\virusQuest\\resources\\index");
		//index at app startup
		idx.indexer();
		//idx.accessIdxDoc("body", 1);
		System.out.println("Index Initialized, App Ready");
		
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainFrame frame = new mainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public mainFrame() throws IOException, ParseException {
		setResizable(false);
		setBackground(new Color(119, 136, 153));
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 979, 593);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(119, 136, 153));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Searcher s = new Searcher("C:\\Users\\Nefeli\\eclipse-workspace\\virusQuest\\resources\\index","C:\\Users\\Nefeli\\eclipse-workspace\\virusQuest\\resources\\spellIndex");
		
		
		JLabel logo = new JLabel("New label");
		logo.setIcon(new ImageIcon("C:\\Users\\Nefeli\\eclipse-workspace\\virusQuest\\resources\\vq_logo.png"));
		logo.setBackground(new Color(240, 240, 240));
		logo.setBounds(0, 0, 244, 45);
		contentPane.add(logo);
		
		inputLine = new JTextField();
		inputLine.setFont(new Font("Courier New", Font.BOLD, 14));
		inputLine.setBounds(254, 5, 530, 36);
		contentPane.add(inputLine);
		inputLine.setColumns(10);
		
				
		
		
		JList list = new JList();
		list.setBounds(97, 235, 191, -156);
		contentPane.add(list);
		
		JPanel panel = new JPanel();
		panel.setBounds(21, 68, 748, 476);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(788, 149, 177, 170);
		contentPane.add(scrollPane);
		

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane_1.setBounds(788, 342, 177, 170);
		contentPane.add(scrollPane_1);
		
		
		JTextArea infoBox = new JTextArea();
		scrollPane.setViewportView(infoBox);
		infoBox.setEditable(false);
		infoBox.setFont(new Font("Courier New", Font.BOLD, 12));
		
		JTextArea suggestionBox = new JTextArea();
		suggestionBox.setFont(new Font("Courier New", Font.BOLD, 12));
		suggestionBox.setEditable(false);
		scrollPane_1.setViewportView(suggestionBox);
		
		
		
		
		JButton r0 = new JButton();			
		r0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                
			                if(authors.get(0).equals(null)) {
			                	r0.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(0)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(0)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(0)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(0)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(0));
			                	
			                	
			                }
			                	
			                
				
				
				
			}
		});
		r0.setText(0+":                                                                      ");
		r0.setFont(new Font("Courier New", Font.BOLD, 15));
		r0.setBounds(30,25+0*43, 700, 38);
		panel.add(r0);
		
		JButton r1 = new JButton();
		r1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(1).equals(null)) {
			                	r1.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(1)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(1)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(1)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(1)+"\n");
			                	textArea.append(content.get(1));
			                	
			                	
			                }
			                	
			                
			                
			                
				
				
				
				
			}
		});
		r1.setText(1+":                                                                      ");
		r1.setFont(new Font("Courier New", Font.BOLD, 15));
		r1.setBounds(30,25+1*43, 700, 38);
		panel.add(r1);
		
		JButton r2 = new JButton();
		r2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(2).equals(null)) {
			                	r2.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(2)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(2)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(2)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(2)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(2));
			                	
			                	
			                }
			                	
			                
			                
			                
				
				
			}
		});
		r2.setText(2+":                                                                      ");
		r2.setFont(new Font("Courier New", Font.BOLD, 15));
		r2.setBounds(30,25+2*43, 700, 38);
		panel.add(r2);
		
		JButton r3 = new JButton();
		r3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(3).equals(null)) {
			                	r3.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(3)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(3)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(3)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(3)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(3));
			                	
			                	
			                }
			                	
				
				
			}
		});
		r3.setText(3+":                                                                      ");
		r3.setFont(new Font("Courier New", Font.BOLD, 15));
		r3.setBounds(30,25+3*43, 700, 38);
		panel.add(r3);
		
		JButton r4 = new JButton();
		r4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(4).equals(null)) {
			                	r4.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(4)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(4)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(4)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(4)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(4));
			                	
			                	
			                }
			                	
				
				
			}
		});
		r4.setText(4+":                                                                      ");
		r4.setFont(new Font("Courier New", Font.BOLD, 15));
		r4.setBounds(30,25+4*43, 700, 38);
		panel.add(r4);
		
		JButton r5 = new JButton();
		r5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(5).equals(null)) {
			                	r5.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(5)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(5)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(5)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(5)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(5));
			                	
			                	
			                }
			                	
			                
				
			}
		});
		r5.setText(5+":                                                                      ");
		r5.setFont(new Font("Courier New", Font.BOLD, 15));
		r5.setBounds(30,25+5*43, 700, 38);
		panel.add(r5);
		
		JButton r6 = new JButton();
		r6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(6).equals(null)) {
			                	r6.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(6)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(6)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(6)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(6)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(6));
			                	
			                	
			                }
			                	
			                
			                
				
			}
		});
		r6.setText(6+":                                                                      ");
		r6.setFont(new Font("Courier New", Font.BOLD, 15));
		r6.setBounds(30,25+6*43, 700, 38);
		panel.add(r6);
		
		JButton r7 = new JButton();
		r7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(7).equals(null)) {
			                	r7.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(7)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(7)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(7)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(7)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(7));
			                	
			                	
			                }
			                	
				
				
			}
		});
		r7.setText(7+":                                                                      ");
		r7.setFont(new Font("Courier New", Font.BOLD, 15));
		r7.setBounds(30,25+7*43, 700, 38);
		panel.add(r7);
		
		JButton r8 = new JButton();
		r8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(8).equals(null)) {
			                	r8.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(8)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(8)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(8)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(8)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(8));
			                	
			                	
			                }
			                	
			                
			                
			                
			}
		});
		r8.setText(8+":                                                                      ");
		r8.setFont(new Font("Courier New", Font.BOLD, 15));
		r8.setBounds(30,25+8*43, 700, 38);
		panel.add(r8);
		
		JButton r9 = new JButton();
		r9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                

			                if(authors.get(9).equals(null)) {
			                	r9.setEnabled(false);
			                }
			                else 
			                {
			                	textArea.append(authors.get(9)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(topics.get(9)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(dates.get(9)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(titles.get(9)+"\n");
			                	textArea.append(" \n");
			                	textArea.append(content.get(9));
			                	
			                	
			                }
			                	
				
				
				
			}
		});
		r9.setText(9+":                                                                      ");
		r9.setFont(new Font("Courier New", Font.BOLD, 15));
		r9.setBounds(30,25+9*43, 700, 38);
		panel.add(r9);
		
		
		ArrayList<JButton> resultsB = new ArrayList<JButton>();
		resultsB.add(r0);
		resultsB.add(r1);
		resultsB.add(r2);
		resultsB.add(r3);
		resultsB.add(r4);
		resultsB.add(r5);
		resultsB.add(r6);
		resultsB.add(r7);
		resultsB.add(r8);
		resultsB.add(r9);
		
		

		JButton nextButton = new JButton("next>>");
		nextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				start=start+10;
				end=end+10;
				
				try {
					authors = s.nextPrevField(results,start,end,"author");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					topics = s.nextPrevField(results,start,end,"topic");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					dates = s.nextPrevField(results,start,end,"date");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					titles =s.nextPrevField(results,start,end,"title");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					content = s.nextPrevField(results,start,end,"body");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				int c=0;
				for(int i=start;i<start+titles.size();i++) 
				{
					
					resultsB.get(c).setText(i+": "+titles.get(c));
					//System.out.println(authors.get(i));
					c++;
				}
				if(10-titles.size()>0) 
				{
					
					for(int j=start+titles.size();j<start+10+1;j++) 
					{
						
						resultsB.get(c).setText(j+":                                                                      ");
						//System.out.println(authors.get(i));
						c++;
					}
					
				}
				
				
			}
		});
		nextButton.setForeground(new Color(0, 0, 139));
		nextButton.setFont(new Font("Courier New", Font.BOLD, 11));
		nextButton.setBounds(883, 89, 82, 36);
		contentPane.add(nextButton);
		
		JButton prevButton = new JButton("<<prev");
		prevButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if((start==0) && (end==10)) 
				{
					//do nothing
				}
				else 
				{
					start=start-10;
					end=end-10;
					try {
						authors = s.nextPrevField(results,start,end,"author");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						topics = s.nextPrevField(results,start,end,"topic");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						dates = s.nextPrevField(results,start,end,"date");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						titles =s.nextPrevField(results,start,end,"title");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						content = s.nextPrevField(results,start,end,"body");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					System.out.println("------------------------");
					int c=0;
					for(int i=start;i<start+titles.size()+1;i++) 
					{
						
						resultsB.get(c).setText(i+": "+titles.get(c));
						//System.out.println(authors.get(i));
						c++;
					}
					if(10-titles.size()>0) 
					{
						
						for(int j=start+titles.size();j<start+10+1;j++) 
						{
							
							resultsB.get(c).setText(j+":                                                                      ");
							//System.out.println(authors.get(i));
							c++;
						}
						
						
					}
					
					
				}
				
				
				
			}
		});
		prevButton.setForeground(new Color(0, 0, 139));
		prevButton.setFont(new Font("Courier New", Font.BOLD, 11));
		prevButton.setBounds(788, 89, 85, 36);
		contentPane.add(prevButton);
		
		JButton questButton = new JButton("Quest!");
		questButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 start=0;
				 end=10;
				
				try {
						results = s.search(inputLine.getText());
				} catch (ParseException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					spellSugg=s.spellSuggestions(inputLine.getText());
					infoBox.setText("");
					 infoBox.append("Alternative queries: \n");
					for(int k=0;k<spellSugg.size();k++)
					{
						infoBox.append(spellSugg.get(k)+"\n");
					}
					
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				try {
					authors = s.nextPrevField(results,start,end,"author");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					topics = s.nextPrevField(results,start,end,"topic");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					dates = s.nextPrevField(results,start,end,"date");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					titles =s.nextPrevField(results,start,end,"title");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					content = s.nextPrevField(results,start,end,"body");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				for(int i=start;i<titles.size();i++) 
				{
					
					resultsB.get(i).setText(i+": "+titles.get(i));
					//System.out.println(authors.get(i));
				}
				if(10-titles.size()>0) 
				{
					
					for(int j=titles.size();j<10;j++) 
					{
						
						resultsB.get(j).setText(j+":                                                                      ");
						//System.out.println(authors.get(i));
					}
					
				}
				
				
				try {
				      File hstr = new File("C:\\Users\\Nefeli\\eclipse-workspace\\virusQuest\\resources\\history.txt");
				      if (hstr.createNewFile()) {
				        System.out.println("File created: " + hstr.getName());
				      } else {
				       	//do nothing,file exists
				      }
				    
				    
				      BufferedWriter bhwriter = new BufferedWriter(new FileWriter(hstr,true));
				      bhwriter.append(inputLine.getText());
				      bhwriter.append("\n");
				      bhwriter.close();
				     historyCounter++;
				    
				      
				      if(historyCounter>=3) 
				      {
				    	  suggestionBox.setText("");
				    	  suggestionBox.append("Recent Queries: \n");
				    	  ReversedLinesFileReader readerReversed= new ReversedLinesFileReader(hstr, Charset.forName("utf-8"));
				    	  for(int n=0 ;n<3;n++) {
				    		  suggestionBox.append(readerReversed.readLine()+"\n");
				    	    
				    	  }
				      }
				      
				      
				      
				    } catch (IOException exc) {
				      System.out.println("An error occurred.");
				      exc.printStackTrace();
				    }
					
					
					
				
				
				
				
				
						
				
			}
		});
		questButton.setFont(new Font("Courier New", Font.BOLD, 15));
		questButton.setBounds(794, 7, 171, 31);
		contentPane.add(questButton);
		
		
		
		

		JButton btnX = new JButton("EXIT");
		btnX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					s.closeSearch();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(0);
				
			}
		});
		btnX.setFont(new Font("Courier New", Font.BOLD, 14));
		btnX.setForeground(new Color(255, 0, 0));
		btnX.setBounds(835, 534, 85, 21);
		contentPane.add(btnX);
		
		
		
		

		JButton historyButton = new JButton("History");
		historyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JFrame frame = new JFrame(" ");
			        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			        JPanel panel = new JPanel();
			                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			                panel.setOpaque(true);
			               
			                JTextArea textArea = new JTextArea(40,80);
			                textArea.setWrapStyleWord(true);
			                textArea.setEditable(false);
			                textArea.setLineWrap(true);
			                textArea.setFont(Font.getFont(Font.SANS_SERIF));
			                
			                JScrollPane scroller = new JScrollPane(textArea);
			                scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			                scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			                JPanel inputpanel = new JPanel();
			                inputpanel.setLayout(new FlowLayout());
			                panel.add(scroller);
			                panel.add(inputpanel);
			                frame.getContentPane().add(BorderLayout.CENTER, panel);
			                frame.pack();
			                frame.setLocationByPlatform(true);
			                frame.setVisible(true);
			                frame.setResizable(false);
			                
			                File hstr = new File("C:\\Users\\Nefeli\\eclipse-workspace\\virusQuest\\resources\\history.txt");
			                Scanner hreader;
							try {
								hreader = new Scanner(hstr);
								  while (hreader.hasNextLine()) {
					                    String line = hreader.nextLine();
					                    textArea.append(line+"\n");
					                    
					                }
					                
								
								
								
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
			              
			                
			                
			                
			
			
			
			
			}
			
			
			
		});
		historyButton.setBackground(UIManager.getColor("FormattedTextField.inactiveBackground"));
		historyButton.setForeground(new Color(128, 0, 128));
		historyButton.setFont(new Font("Courier New", Font.BOLD, 11));
		historyButton.setBounds(788, 48, 85, 31);
		contentPane.add(historyButton);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		JButton historyCLRButton = new JButton("CLR Hist");
		historyCLRButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				File hstr = new File("C:\\Users\\Nefeli\\eclipse-workspace\\virusQuest\\resources\\history.txt");
				
				 try {
					if (hstr.createNewFile()) {
					        System.out.println("File created: " + hstr.getName());
					} else {
					    	PrintWriter cleaner = new PrintWriter(hstr);
							cleaner.print("");
							cleaner.close();
								
					      }
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		historyCLRButton.setForeground(new Color(128, 0, 128));
		historyCLRButton.setFont(new Font("Courier New", Font.BOLD, 10));
		historyCLRButton.setBackground(UIManager.getColor("FormattedTextField.inactiveBackground"));
		historyCLRButton.setBounds(883, 48, 85, 31);
		contentPane.add(historyCLRButton);
		
		
		
	}
}
