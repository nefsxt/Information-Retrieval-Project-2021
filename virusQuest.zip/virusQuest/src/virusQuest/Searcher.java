package virusQuest;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;



import org.apache.lucene.document.Document;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;

import org.apache.lucene.index.IndexWriterConfig;

import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;

import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;

import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.spell.LuceneDictionary;
import org.apache.lucene.search.spell.SpellChecker;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;




public class Searcher {
	 
	private File dirFile;
	private File spellDirFile;
	private Directory dir;
	private Directory spellDir;
	private IndexReader indexReader;
	private IndexWriterConfig configS1 ;
	private IndexWriterConfig configS2 ;
	private IndexWriterConfig configS3 ;
	private IndexWriterConfig configS4 ;
	private IndexWriterConfig configS5 ;
	private IndexSearcher indexSearcher;
	private SpellChecker spellChecker;
	
	public Searcher(String dirPath,String spellDirPath) throws IOException 
	{
		
		this.dirFile = new File(dirPath);
		this.spellDirFile = new File(spellDirPath);
	    this.dir = FSDirectory.open(dirFile.toPath());
	    this.spellDir = FSDirectory.open(spellDirFile.toPath());
	    this.indexReader = DirectoryReader.open(dir);
	    this.indexSearcher = new IndexSearcher(indexReader);
	    StandardAnalyzer analyzer = new StandardAnalyzer();
	    this.configS1 = new IndexWriterConfig(analyzer);
	    this.configS2 = new IndexWriterConfig(analyzer);
	    this.configS3 = new IndexWriterConfig(analyzer);
	    this.configS4 = new IndexWriterConfig(analyzer);
	    this.configS5 = new IndexWriterConfig(analyzer);
	    this.spellChecker = new SpellChecker(this.spellDir);
	    this.spellChecker.indexDictionary(new LuceneDictionary(this.indexReader, "author"),this.configS1,true);
	    this.spellChecker.indexDictionary(new LuceneDictionary(this.indexReader, "topic"),this.configS2,true);
	    this.spellChecker.indexDictionary(new LuceneDictionary(this.indexReader, "date"),this.configS3,true);
	    this.spellChecker.indexDictionary(new LuceneDictionary(this.indexReader, "title"),this.configS4,true);
	    this.spellChecker.indexDictionary(new LuceneDictionary(this.indexReader, "body"),this.configS5,true);


	    
	    
	}
	
	

	
	
	
	public TopDocs search(String userQuery) throws ParseException, IOException
	{
		String[] fields= {"author","topic","date","title","body"};
		MultiFieldQueryParser qparser = new MultiFieldQueryParser( fields, new StandardAnalyzer() );
		Query query = qparser.parse(userQuery);
		int topHits = 700;
		TopDocs topDocs = this.indexSearcher.search(query,topHits);
		return topDocs;
	}
	
	
	public ArrayList<String> spellSuggestions(String userQuery) throws IOException
	{
		
			int noOfsuggestion = 2; //number of suggestions
			ArrayList<String> res = new ArrayList<String>();
			
        String[] altSpell = spellChecker.suggestSimilar(userQuery, noOfsuggestion); //get suggestions
 
        //check if they exist before adding them to the results ArrayList which is to be returned by the method
        if (altSpell!=null && altSpell.length>0) {
            for (String suggestion : altSpell) {
                res.add(suggestion);
            	//System.out.println(suggestion);
            }
        }  
		
		 return res;
	}
	
	public ArrayList<String> nextPrevField(TopDocs topDocs,int start,int end,String field) throws IOException 
	{
		ArrayList<String> results = new ArrayList<String>();
		
		//iterate over topDocs.scoreDocs from start to end (since we display 10 results it is always 10)
		for(int i=start;i<end;i++)
		{
			int docid = topDocs.scoreDocs[i].doc;
			Document d = this.indexSearcher.doc(docid);
			double score = topDocs.scoreDocs[i].score;
			String fieldContent = d.get(field);
			results.add(fieldContent);
			//check if end if topdocs bc "end" might be greater than scoreDocs length
		    if(topDocs.scoreDocs.length-(i+1)==0) 
		    {
		    	//System.out.println("NO MORE RESULTS");
		    	return results;
		    }
		}
		return results;
	}
	
	
	
	//close IndexReader and Directories
	
	public void closeSearch() throws IOException
	{   //close IndexReader and Directories
		this.indexReader.close();
		this.dir.close();
		this.spellDir.close();
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
