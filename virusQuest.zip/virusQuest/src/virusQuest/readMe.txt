
I redid all the gui in WindowsBuilder to ensure everything will stick together with greater ease and less bugs

a big pro out of all of this, is that WindowsBuilder gives back code that makes sense 

the icon for the "mainFrame" class (aka the gui class)is set to a path on my pc so it won't compile
you probably will need to throw the gui file out of the package to test other things bc there are two mains rn
