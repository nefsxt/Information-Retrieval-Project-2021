import csv

fileName = "covid19_data"
rowNum = 700
rowCount = 0
with open('covid.csv', encoding="cp1252") as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        if rowCount == 0:
            print(f'Columns in CSV file are {", ".join(row)}')
            rowCount += 1
        else:
            text_file = open(''.join([fileName, str(rowCount), '.txt']), 'w', encoding="utf8")
            text_file.write(row[0]+'\n'+row[6]+'\n'+row[1]+'\n'+row[3]+'\n'+row[5])
            text_file.flush()
            text_file.close()
            rowCount += 1
            
        if rowCount > rowNum:
            print('txt files created!')
            break
    print(f'Processed {rowNum} rows.')
