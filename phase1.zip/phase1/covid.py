import csv

fileName = "covid19_data"
rowNum = 200
rowCount = 0
with open('COVID_DATA.csv', encoding="utf8") as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        if rowCount == 0:
            print(f'Columns in CSV file are {", ".join(row)}')
            rowCount += 1
        else:
            text_file = open(''.join([fileName, str(rowCount), '.txt']), 'w', encoding="utf8")
            text_file.write("Author: "+row[0]+'\n'+"Topic: "+row[6]+'\n'+"Date: "+row[1]+'\n'+"Title: "+row[3]+'\n\n'+"Body:\n"+row[5])
            text_file.flush()
            text_file.close()
            rowCount += 1
            
        if rowCount > rowNum:
            print('txt files created!')
            break
    print(f'Processed {rowNum} rows.')
